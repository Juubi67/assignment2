import { create } from "zustand";

interface UserState {
  user: {
    _id: string;
    firstName: string;
    lastName: string;
    email: string;
  } | null;
  registerError: null | { code: string | number; message: string };
  loginError: null | { code: string | number; message: string };
  fetchUserLoading: boolean;
  emailPaswordLoading: boolean;
  passwordResetLoading: boolean;
  resendEmailOTPTimer: boolean;

  setUser: (user: any) => void;
  setRegisterError: (params: { code: string; message: string } | null) => void;
  setLoginError: (params: { code: string; message: string } | null) => void;
  setFetchUserLoading: (value: boolean) => void;
  setEmailPasswordLoading: (value: boolean) => void;
  setPasswordResetLoading: (value: boolean) => void;
  setResendEmailOTPTimer: (value: boolean) => void;
}

const useAuthStore = create<UserState>()((set) => ({
  user: null,
  loginError: null,
  registerError: null,
  fetchUserLoading: true,
  emailPaswordLoading: false,
  passwordResetLoading: false,
  resendEmailOTPTimer: false,

  setUser: (user) => {
    set((state) => ({
      ...state,
      user: user,
    }));
  },

  setLoginError: (params) => {
    set((state) => ({
      ...state,
      loginError: params
        ? { code: params.code, message: params.message }
        : null,
    }));
  },

  setRegisterError: (params) => {
    set((state) => ({
      ...state,
      registerError: params
        ? { code: params.code, message: params.message }
        : null,
    }));
  },

  setFetchUserLoading: (value) => {
    set((state) => ({
      ...state,
      fetchUserLoading: value,
    }));
  },

  setEmailPasswordLoading: (value) => {
    set((state) => ({
      ...state,
      emailPaswordLoading: value,
    }));
  },

  setPasswordResetLoading: (value) => {
    set((state) => ({
      ...state,
      passwordResetLoading: value,
    }));
  },

  setResendEmailOTPTimer: (value) => {
    set((state) => ({
      ...state,
      resendEmailOTPTimer: value,
    }));
  },
}));

export default useAuthStore;
