import { createContext, useContext, useEffect, useState } from "react";
import fetcher from "../utilities/fetcher";
import useAuthStore from "../store/authStore";
import { useNavigate } from "react-router-dom";

export type RegisterParams = {
  firstName: string;
  lastName: string;
  email: string;
  password: string;
};

export type SignInParams = {
  email: string;
  password: string;
};

const AuthContext = createContext({
  fetchUserPromise: async () => Promise<unknown>,
  signIn: (params: SignInParams) => Promise<unknown>,
  register: (params: RegisterParams) => Promise<unknown>,
  signOut: (): void => {},
});

export const useAuth = (): any => {
  return useContext(AuthContext);
};

export const AuthContextProvider = ({ children }: { children: any }) => {
  const navigate = useNavigate();
  const { user, setUser, setEmailPasswordLoading } = useAuthStore();

  useEffect(() => {
    const token = localStorage.getItem(`${__TOKEN_PREFIX__}_token`);
    getCurrentUser(token);
  }, []);

  const getCurrentUser = async (token: string | null) => {
    try {
      if (!user) {
        if (token) {
          const { data } = await fetcher().get("user/whoami");
          setUser(data);
        }
      } else {
        return setUser;
      }
    } catch (error) {
      console.log(error);
    }
  };

  const signIn = async (signInParams: SignInParams) => {
    setEmailPasswordLoading(true);
    const url: string = `${__BACKEND_URL__}/user/login`;
    try {
      const { data: user } = await fetcher().post(url, {
        email: signInParams.email,
        password: signInParams.password,
      });
      setUser(user);
      localStorage.setItem(`${__TOKEN_PREFIX__}_token`, user.token);
    } catch (error) {
      console.log(error);
    } finally {
      setEmailPasswordLoading(false);
    }
  };

  const register = async (registerParams: RegisterParams) => {
    setEmailPasswordLoading(true);
    const url: string = `${__BACKEND_URL__}/user/register`;
    try {
      const { data: user } = await fetcher().post(url, {
        firstName: registerParams.firstName,
        lastName: registerParams.lastName,
        email: registerParams.email,
        password: registerParams.password,
      });
      setUser(user);
      localStorage.setItem(`${__TOKEN_PREFIX__}_token`, user.token);
    } catch (error) {
      console.log(error);
    } finally {
      setEmailPasswordLoading(false);
    }
  };

  const signOut = () => {
    localStorage.removeItem(`${__TOKEN_PREFIX__}_token`);
    setUser(null);
  };

  async function fetchUserPromise() {
    return new Promise(async (resolve) => {
      const token = localStorage.getItem(`${__TOKEN_PREFIX__}_token`);
      const user = await getCurrentUser(token);
      resolve(user);
    });
  }

  const value: any = {
    fetchUserPromise,
    signIn,
    register,
    signOut,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};
