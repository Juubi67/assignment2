import React, { Suspense } from "react";
import ReactDOM from "react-dom/client";
import "./index.css";
import {
  Navigate,
  Route,
  RouterProvider,
  createBrowserRouter,
  createRoutesFromElements,
} from "react-router-dom";
import RootLayout from "./layout/RootLayout.tsx";
import FallbackLoading from "./layout/FallBackLoading.tsx";
import OnlyPublicRoutes from "./router/OnlyPublicRoutes.tsx";
import Login from "./pages/Login.tsx";
import Register from "./pages/Register.tsx";
import PrivateRoutes from "./router/PrivateRoute.tsx";
import Employees from "./pages/employee/Employees.tsx";
import EditEmployee from "./pages/employee/EditEmployee.tsx";
import Navbar from "./layout/Navbar.tsx";
import NavbarFooter from "./layout/NavbarFooter.tsx";
import CreateEmployee from "./pages/employee/CreateEmployee.tsx";
import EmployeeDetail from "./pages/employee/EmployeeDetail.tsx";
import Home from "./pages/Home.tsx";

const router = createBrowserRouter(
  createRoutesFromElements(
    <Route path="/" element={<RootLayout />}>
      <Route path="/" element={<NavbarFooter />}>
        <Route index element={<Home />} />
      </Route>

      <Route
        path="/user"
        element={
          <Suspense fallback={<FallbackLoading />}>
            <OnlyPublicRoutes fallbackUrl="/" />
          </Suspense>
        }
      >
        <Route path="login" element={<Login />} />
        <Route path="register" element={<Register />} />
      </Route>

      <Route path="/employee" element={<NavbarFooter />}>
        <Route
          path="/employee"
          element={
            <Suspense fallback={<FallbackLoading />}>
              <PrivateRoutes fallbackUrl="/user/login" />
            </Suspense>
          }
        >
          <Route path="create" element={<CreateEmployee />} />
          <Route index element={<Employees />} />
          <Route path="edit/:id" element={<EditEmployee />} />
          <Route path="view/:id" element={<EmployeeDetail />} />
        </Route>
      </Route>
    </Route>,
  ),
);

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <RouterProvider router={router} />
  </React.StrictMode>,
);
