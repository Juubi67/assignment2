import { useMutation } from "react-query";
import fetcher from "../../utilities/fetcher";
import { CreateEmployeeInputType } from "../../pages/employee/CreateEmployee";

const useCreateEmployee = () => {
  return useMutation({
    mutationKey: ["create-employee"],
    mutationFn: async (body: CreateEmployeeInputType) => {
      const { data } = await fetcher().post("/employee", body);
      return data;
    },
  });
};

export default useCreateEmployee;
