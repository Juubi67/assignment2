import { useMutation } from "react-query";
import fetcher from "../../utilities/fetcher";
import { EditEmployeeInputType } from "../../pages/employee/EditEmployee";

const useEditEmployee = () => {
  return useMutation({
    mutationKey: ["edit-employee"],
    mutationFn: async (body: EditEmployeeInputType & { id: string }) => {
      const { id, ...payload } = body;
      const { data } = await fetcher().put(`/employee/${id}`, payload);
      return data;
    },
  });
};

export default useEditEmployee;
